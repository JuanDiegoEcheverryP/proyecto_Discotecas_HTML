class etiqueta {
  constructor(idEtiqueta, nombreEtiqueta) {
    this.idEtiqueta = idEtiqueta;
    this.nombreEtiqueta = nombreEtiqueta;
  }
  getIdEtiqueta() {
    return this.idEtiqueta;
  }
  setIdEtiqueta(newEtiqueta) {
    this.idEtiquetas = this.newEtiqueta;
  }
  getNombreEtiqueta() {
    return this.nombreEtiqueta;
  }
  setNombreEtiqueta(newEtiqueta) {
    this.nombreEtiqueta = this.newEtiqueta;
  }
}

console.log("clase etiqueta: Cargado");