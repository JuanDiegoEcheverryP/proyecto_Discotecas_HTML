class localidad {
  constructor(idLocalidad, localidad) {
    this.idLocalidad = idLocalidad;
    this.localidad = localidad;
  }
  getIdLocalidad() {
    return this.idLocalidad;
  }
  setIdLocalidad(newLocalidad) {
    this.idLocalidads = this.newLocalidad;
  }
  getLocalidad() {
    return this.localidad;
  }
  setLocalidad(newlocalidad) {
    this.localidad = this.newlocalidad;
  }
}

console.log("clase localidad: Cargado");