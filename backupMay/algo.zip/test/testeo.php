<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
	<title>Discotecas</title>
</head>
<body>
	<script type="text/javascript">
		document.write(localStorage.getItem("nombre_variable"));
		window.onload = alert(localStorage.getItem("nombre_variable"));
	</script>
</body>